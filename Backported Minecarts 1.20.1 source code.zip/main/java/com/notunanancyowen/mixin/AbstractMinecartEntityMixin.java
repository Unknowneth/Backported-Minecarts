package com.notunanancyowen.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.notunanancyowen.MinecartBackport;
import net.minecraft.block.AbstractRailBlock;
import net.minecraft.block.BlockState;
import net.minecraft.block.enums.RailShape;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.vehicle.AbstractMinecartEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractMinecartEntity.class)
public abstract class AbstractMinecartEntityMixin extends Entity {
    @Shadow public abstract boolean isOnRail();
    @Shadow private int clientInterpolationSteps;
    @Shadow private double clientYaw;
    @Unique private RailShape lastRail;
    @Unique private double lastVelocity;
    @Unique private int subticks;
    public AbstractMinecartEntityMixin(EntityType<?> type, World world) {
        super(type, world);
        lastRail = RailShape.NORTH_SOUTH;
        lastVelocity = 0.0;
        subticks = 0;
    }
    @Inject(method = "<init>(Lnet/minecraft/entity/EntityType;Lnet/minecraft/world/World;)V", at = @At("TAIL"))
    private void assignDefaultValues(EntityType<?> entityType, World world, CallbackInfo ci) {
        lastRail = RailShape.NORTH_SOUTH;
        lastVelocity = 0.0;
        subticks = 0;
    }
    @ModifyConstant(method = "tick", constant = @Constant(doubleValue = 0.001))
    private double makeVanillaConditionUnachievable(double constant) {
        return Double.MAX_VALUE;
    }
    @ModifyExpressionValue(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/AbstractRailBlock;isRail(Lnet/minecraft/block/BlockState;)Z"))
    private boolean launchFromRail(boolean original) {
        if(lastRail != null && isOnRail() && !original) {
            switch (lastRail) {
                case ASCENDING_EAST, ASCENDING_WEST -> this.addVelocity((lastVelocity - 0.0078125) * Math.signum(getVelocity().getX()), lastVelocity * (getY() < prevY ? -1 : 1), 0);
                case ASCENDING_NORTH, ASCENDING_SOUTH -> this.addVelocity(0, lastVelocity * (getY() < prevY ? -1 : 1), (lastVelocity - 0.0078125) * Math.signum(getVelocity().getZ()));
            }
            this.setPosition (this.getPos().add(this.getVelocity().multiply(0, 0.95, 0)).add(0, getY() < prevY ? 0 : 0.3, 0));
            this.resetPosition();
            this.refreshPosition();
            this.noClip = false;
        }
        else lastVelocity = Math.sqrt(getVelocity().length()) / 2 * 0.95;
        return original;
    }
    @Inject(method = "getMaxSpeed", at = @At("TAIL"), cancellable = true)
    private void changeMaxSpeed(CallbackInfoReturnable<Double> cir) {
        double maxSpeed = this.getWorld().getGameRules().getInt(MinecartBackport.MINECART_MAX_SPEED);
        if(isOnRail() && maxSpeed > 8.0) maxSpeed = 8.0;
        if(this.isTouchingWater()) maxSpeed *= 0.5;
        cir.setReturnValue(maxSpeed / 20.0);
    }
    @WrapMethod(method = "tick")
    private void moveFaster(Operation<Void> original) {
        original.call();
        if(!isOnRail()) return;
        double maxSpeed = this.getWorld().getGameRules().getInt(MinecartBackport.MINECART_MAX_SPEED) / 8.0;
        if(maxSpeed <= 1.0) return;
        maxSpeed--;
        while(maxSpeed >= 1.0) {
            original.call();
            maxSpeed--;
        }
        if(++subticks > (1.0 - maxSpeed) * 8.0) {
            subticks = 0;
            original.call();
        }
    }
    @Inject(method = "moveOnRail", at = @At(value = "INVOKE", target = "Lnet/minecraft/block/BlockState;get(Lnet/minecraft/state/property/Property;)Ljava/lang/Comparable;", ordinal = 1))
    private void getRailType(BlockPos pos, BlockState state, CallbackInfo ci) {
        lastRail = state.get(((AbstractRailBlock)state.getBlock()).getShapeProperty());
    }
    @Inject(method = "tick", at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/vehicle/AbstractMinecartEntity;updateWaterState()Z"))
    private void fixYawRotation(CallbackInfo ci) {
        if(firstUpdate && getWorld().getBlockState(getBlockPos()).getBlock() instanceof AbstractRailBlock rail) {
            lastRail = getWorld().getBlockState(getBlockPos()).get(rail.getShapeProperty());
            switch (lastRail) {
                case EAST_WEST, ASCENDING_EAST, ASCENDING_WEST -> setYaw(-90);
            }
            setYaw(getYaw() + 90);
            clientYaw = prevYaw = getYaw();
            clientInterpolationSteps = 0;
        }
        else if(getVelocity().getX() != 0 || getVelocity().getZ() != 0) setYaw((float)(Math.atan2(getVelocity().z, getVelocity().x) * 180 / Math.PI));
    }
    @Override public void setPitch(float pitch) {
        if(getWorld() == null) super.setPitch(pitch);
        else if(isOnGround()) super.setPitch(0);
        else super.setPitch(getPitch() + (MathHelper.clamp(180 * (float)getVelocity().getY() * (float)MathHelper.clamp(getVelocity().multiply(10, 0, 10).length(), 0, 1), -45, 45) - this.getPitch()) * (this.getPitch() == 0F ? 1F : 0.1F));
    }
}
